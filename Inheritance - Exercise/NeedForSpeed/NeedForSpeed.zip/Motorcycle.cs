﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(double fuel, int horcePower) : base(fuel, horcePower)
        {
        }
    }
}
