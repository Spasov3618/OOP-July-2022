﻿
namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int horcePower, double fuel) : base(horcePower, fuel)
        {
        }
    }
}
