﻿namespace NeedForSpeed
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horcePower, double fuel) : base(horcePower, fuel)
        {
        }
    }

}
