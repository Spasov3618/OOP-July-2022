﻿
namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horcePower, double fuel) : base(horcePower, fuel)
        {
        }
    }
}
