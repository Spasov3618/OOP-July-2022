﻿
namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(double fuel, int horcePower) : base(fuel, horcePower)
        {
        }
    }
}
