﻿namespace Cars
{
    public interface IElectricCar
    {
        int Bateries { get; }
    }
}