﻿namespace BorderControl
{
    public interface IAdded
    {
        string Id { get; set; }
    }
}
