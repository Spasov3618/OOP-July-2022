﻿using System;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engin engin = new Engin();
            engin.Run();
        }
    }
}
