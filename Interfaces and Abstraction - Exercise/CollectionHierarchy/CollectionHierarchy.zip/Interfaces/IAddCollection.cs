﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddCollection
    {
        int Add(string element);
    }
}