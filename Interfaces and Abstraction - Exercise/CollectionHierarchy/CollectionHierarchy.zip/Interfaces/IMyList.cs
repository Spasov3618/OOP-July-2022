﻿namespace CollectionHierarchy.Interfaces
{
    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}