﻿namespace MilitaryElite
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}