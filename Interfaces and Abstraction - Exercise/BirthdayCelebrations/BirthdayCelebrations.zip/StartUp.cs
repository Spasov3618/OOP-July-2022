﻿using System;

namespace BirthdayCelebrations
{
    public class StartUp
    {
        static void Main()
        {
            Engin engin = new Engin();
            engin.Run();
        }
    }
}
