﻿namespace BirthdayCelebrations
{
    public interface IAdded
    {
        string Id { get; set; }
    }
}
