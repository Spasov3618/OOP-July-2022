﻿

namespace BirthdayCelebrations
{
    public interface IBirthday
    {
        string Birthday { get; set; }
    }
}
